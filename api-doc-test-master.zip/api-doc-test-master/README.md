ApplicationPower api-doc接口文档自动生成工具测试代码。

**注：** 本项目基本框架代码由application-power自动生成。想要体验者欢迎到https://github.com/shalousun/ApplicationPower
或者https://gitee.com/sunyurepository/ApplicationPower浏览详情。