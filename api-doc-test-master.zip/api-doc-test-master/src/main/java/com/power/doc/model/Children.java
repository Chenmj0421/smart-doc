package com.power.doc.model;

/**
 * @author yu 2018/7/9.
 */
public class Children extends Parent{

    /**
     * 年龄
     */
    private int age;

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }
}
