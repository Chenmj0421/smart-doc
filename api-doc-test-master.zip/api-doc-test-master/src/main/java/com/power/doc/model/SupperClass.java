package com.power.doc.model;

/**
 * @author yu 2018/7/10.
 */
public class SupperClass {

    /**
     * 地址
     */
    public String address;
}
