package com.power.doc.entity;

/**
 * @author Exrick
 */
public class RolePermission extends XbootBaseEntity {

    private static final long serialVersionUID = 1L;

    private String roleId;

    private String permissionId;
}