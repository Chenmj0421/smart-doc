package com.power.doc.entity;



/**
 * @author Exrickx
 */

public class UserRole extends XbootBaseEntity {

    private static final long serialVersionUID = 1L;

    private String userId;

    private String roleId;

    private String roleName;
}
