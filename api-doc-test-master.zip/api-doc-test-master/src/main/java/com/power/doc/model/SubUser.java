package com.power.doc.model;

/**
 * Description:
 * 子用户
 *
 * @author yu 2018/06/15.
 */
public class SubUser {

    /**
     * 用户名称
     */
    private String subUserName;


    public String getSubUserName() {
        return subUserName;
    }

    public void setSubUserName(String subUserName) {
        this.subUserName = subUserName;
    }
}
